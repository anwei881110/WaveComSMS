HOW TO BUILD SMSLib .NET ASSEMBLY

First of all, run "get_ikvm.bat". This will fetch and unzip the IKVM application.

1) Run "ant build-smslib" from the top level directory in order to build the Java library.
2) Run "build-net.bat" to build the SMSLib .NET assembly. The assembly is placed at [project-root]/dist/lib.
